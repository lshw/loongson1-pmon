commit f6664a9c229aab54ed502afb448a2fb089077f97
Author: liu shiwei <liushiwei@gmail.com>
Date:   Sun Aug 28 16:12:26 2016 +0800

    忽略 .rej文件

commit 20230504f050a5cdd522dae1fd33f75bc6aac97f
Author: liu shiwei <liushiwei@gmail.com>
Date:   Sun Aug 28 13:23:46 2016 +0800

    增加说明文件

commit 8dfbcd2d79ad32e50a358225902afb3a9b25b774
Author: liu shiwei <liushiwei@gmail.com>
Date:   Sun Aug 28 13:13:03 2016 +0800

    从万由unas板，引入的一个修改

commit 81eaaed5ac3f3927223687f0b30e30c02853a62c
Author: liu shiwei <liushiwei@gmail.com>
Date:   Sun Aug 28 13:11:42 2016 +0800

    开机等待回车太短

commit 99667c1f1f124f37557d152cc229ca76552265a9
Author: liu shiwei <liushiwei@gmail.com>
Date:   Sat Aug 27 15:53:53 2016 +0800

    load speed add

commit 0805fa3c03647e53eef9792688d09d4d06ba7111
Author: liu shiwei <liushiwei@gmail.com>
Date:   Sun Aug 28 12:37:27 2016 +0800

    清理

commit 5cd5f64b90e0e1348708f4ceed7e26a6d6262177
Author: liu shiwei <liushiwei@gmail.com>
Date:   Sun Aug 28 12:25:09 2016 +0800

    fix vers

commit 13435d6ab8d45df0a23dbcf51e9537ce6a952527
Author: liu shiwei <liushiwei@gmail.com>
Date:   Sun Aug 28 12:10:41 2016 +0800

    没有pmoncfg时，自动编译一个

commit af813ea2a87878e03b7e6b3f238a89753a449c73
Author: liu shiwei <liushiwei@gmail.com>
Date:   Sun Aug 28 12:08:38 2016 +0800

    新的编译脚本，自动从ustc下载交叉编译环境，生成ram和rom2个文件，在debian5-debian9 下测试通过

commit 7f95834b6b7a0453b8c326d04219a3e2477408e4
Author: liu shiwei <liushiwei@gmail.com>
Date:   Wed Mar 16 14:35:45 2016 +0800

    release ls1c开龙主板 pmon 20160315

commit f7b8a59e695ccce80dc788834493c12a73e751d5
Author: liu shiwei <liushiwei@gmail.com>
Date:   Wed Mar 16 14:12:18 2016 +0800

    loongson1c build err ,

commit 9e0d27e2b0a00e309bbae4e30a1e67fb3fc5fa28
Author: liu shiwei <liushiwei@gmail.com>
Date:   Wed Mar 16 14:11:36 2016 +0800

    fatfs_fast.h -> fatfs.h

commit dff7d8fad165cf338fde8f4b82049b58de6c2975
Author: liu shiwei <liushiwei@gmail.com>
Date:   Wed Mar 16 12:52:58 2016 +0800

    remove module fatfs_fast , merge into module fatfs.

commit bc8b9df8e33a348f4d022fe87eb0a8d4259d0687
Author: liu shiwei <liushiwei@gmail.com>
Date:   Wed Mar 16 12:45:41 2016 +0800

    fix fat error bug

commit eec50ffb8bf2fa34e9a3febc661872766918000b
Author: liu shiwei <liushiwei@gmail.com>
Date:   Thu Mar 3 10:35:00 2016 +0800

    release ls1B开发板 pmon 20160303

commit 95d836c8c7e20c450aa84cfce8533f3e67670c2d
Author: liu shiwei <liushiwei@gmail.com>
Date:   Thu Mar 3 10:25:27 2016 +0800

    因为有些usb设备会造成pmon死锁，这里关闭LS1B开发板的4个u口的上面2个，
    可以把这个usb设备插在远离线路板的2个口，
    而升级优盘，只能插下面靠近线路板的2个u口才可以认。

commit efacaceeac61ec1bb81d24ff50a5a68c3849cb44
Author: liu shiwei <liushiwei@gmail.com>
Date:   Thu Mar 3 10:07:57 2016 +0800

    修改run_1b.sh run_1c.sh
    
    用xutils-dev包里的makedepend，好像不是很合适。不过能用。

commit 9fccf29437b6801d4cda1755559bc67dfd2d3780
Author: liu shiwei <liushiwei@gmail.com>
Date:   Thu Mar 3 09:47:01 2016 +0800

    增加loongson1b开发板的编译脚本

commit 2a7e50cd4bbc45f4694f7d8e4b02e0bdafcdc498
Author: liu shiwei <liushiwei@gmail.com>
Date:   Wed Mar 2 21:02:03 2016 +0800

    loongson1B开发板，在插某些usb3G网卡时，会pmon会死机，
    判断一下，如果插在上面2个usb口（port=1,3) 就跳过。

commit 74dd4672dc757ec357f30a4621201ac699576d93
Author: liu shiwei <liushiwei@gmail.com>
Date:   Mon Dec 14 17:37:51 2015 +0800

    fix

commit c730e3e2f6efb27f1b265cc8d80a5b29432778a8
Author: root <root@bak1.ht.anheng.com.cn>
Date:   Mon Dec 14 17:17:47 2015 +0800

    loongson1B always autoexec=yes.

commit d35ef679e55fbd82f045109ec7e48c16cdd34e29
Author: liu shiwei <liushiwei@gmail.com>
Date:   Mon Dec 14 17:08:24 2015 +0800

    add LSGZ_1B_DEV ver 2.0 hardware.

commit a206fe4b56632fadd3edc29fdd1191337a596af7
Author: liu shiwei <liushiwei@gmail.com>
Date:   Fri Nov 6 12:26:50 2015 +0800

    增加giturl到 vers显示， 去掉编译ip和user显示

commit 5689b3094acd22c56003cc3b27f0d75e23a8d5b4
Author: liu shiwei <liushiwei@gmail.com>
Date:   Wed Nov 4 16:26:25 2015 +0800

    启用cat命令， 用来显示文件， ls命令， 用来列出目录

commit f95f420e1e1f008dbc3b7edb77f4a053061d1815
Author: liu shiwei <liushiwei@gmail.com>
Date:   Wed Nov 4 09:15:01 2015 +0800

    old_ver 需要分配内存，  修复循环重启问题。

commit 0d32c08f65afc2e79e75bf8a61cf9168f8cecfc2
Author: liu shiwei <liushiwei@gmail.com>
Date:   Wed Nov 4 08:56:04 2015 +0800

    fat_fast模块可能有内存泄露， 造成很多问题， 换成fat模块

commit 9938e8a8ed5bcb1d8a5afaeaf155bf05b26710d6
Author: liu shiwei <liushiwei@gmail.com>
Date:   Wed Nov 4 08:55:15 2015 +0800

    环境变量不要带下划线，更新完成，自动reboot.

commit d3633fca5b8853dfde98e51927bf050b2f209595
Author: liu shiwei <liushiwei@gmail.com>
Date:   Fri Oct 30 00:58:49 2015 +0800

    编译脚本调整

commit 8912c13fd176084e1b195002c9f2f0f229a5ba25
Merge: 285eff5 bb0aa2a
Author: liu shiwei <liushiwei@gmail.com>
Date:   Fri Oct 30 00:53:48 2015 +0800

    Merge branch 'master' of https://github.com/lshw/loongson1-pmon

commit 285eff58f8487cf4403a8d35069d9d64fa6ef359
Author: liu shiwei <liushiwei@gmail.com>
Date:   Fri Oct 30 00:05:57 2015 +0800

    char * getenv(char * name);
    
    这个getenv()函数，在name找不到的情况下，会返回0，
    后面如果用getenv()的返回值0作参数， 进行strcmp,strcpy等操作时，系统就会出问题，
    因此，需要对返回值进行判断，并处理， 才可以安全的进行strcmp,
    这次搜索了全部的pmon中的getenv()，发现大部分都很好的处理了0值情况，
    但也有一些未做处理， 可能会存在隐患，因此，这里集中处理了一下。

commit bb0aa2a649c3c24e141dfc0d6e54526e9637f31e
Author: liu shiwei <liushiwei@gmail.com>
Date:   Fri Oct 30 00:05:57 2015 +0800

    char * getenv(char * name);
    这个getenv()函数，在name找不到的情况下，会返回0，
    后面如果用getenv()的返回值0作参数， 进行strcmp,strcpy等操作时，系统就会出问题，
    因此，需要对返回值进行判断，并处理， 才可以安全的进行strcmp,
    这次搜索了全部的pmon中的getenv()，发现大部分都很好的处理了0值情况，
    但也有一些未做处理， 可能会存在隐患，因此，这里集中处理了一下。

commit adf068c3d11380d32d000485a3b3c5932508e741
Author: liu shiwei <liushiwei@gmail.com>
Date:   Thu Oct 29 01:06:59 2015 +0800

    增加autoexec.bat功能
    
    用于自动更新系统，或者自动载入linux
    
    autoexec.bat 第一行是版本，
    
    如果第一行的第一个字符是'#',就会每次都执行，
    类似于dos的autoexec.bat。
    
    如果第一行第一个字母不是‘#‘,则autoexec.bat
    将作为自动升级脚本， 只执行一次， 具有相同
    版本号的autoexec.bat将不再执行。

commit 21526de0cb4f73f70770bdebdadb46c16d3aff82
Author: liu shiwei <liushiwei@gmail.com>
Date:   Tue Oct 27 23:52:07 2015 +0800

    修复在新版本的linux下不能获取当前ip问题
    在新版本的linux下，网卡名称变化很大，原来的方式已经不能获取ip了

commit 11fa4de17b392736046c353f2fb599df7e250c5c
Author: liu shiwei <liushiwei@gmail.com>
Date:   Tue Oct 27 23:46:31 2015 +0800

    修复CommitAuthor和CommitDate显示不全的问题.
    
    显示不全:
    CommitAuthor: liu
    CommitDate: Date: The Oct 27 11:41:00
    
    修复后:
    CommitAuthor: liu shiwei <liushiwei@gmail.com>
    CommitDate: Date: Tue Oct 27 11:41:00 2015 +0800

commit 3216605c470543e400c9b68185a40ac51e549ef8
Author: liu shiwei <liushiwei@gmail.com>
Date:   Tue Oct 27 11:41:00 2015 +0800

    自动编译脚本

commit bfa9fd109bf140360c431702fb1d851926f8230d
Author: liu shiwei <liushiwei@gmail.com>
Date:   Tue Oct 27 11:40:39 2015 +0800

    让make pmoncfg 可以执行

commit 743405cae774174f7bd8a20ee10439b5f377b805
Author: liu shiwei <liushiwei@gmail.com>
Date:   Tue Oct 27 11:40:02 2015 +0800

    清理文件

commit 3820da445fa1819b193d0432ed40189235ce3e4b
Author: liu shiwei <liushiwei@gmail.com>
Date:   Tue Oct 27 11:29:26 2015 +0800

    增加openloongson的独立配置

commit 641b0ecf2245a6fb4277a6419b907efb1bccff8e
Author: liu shiwei <liushiwei@gmail.com>
Date:   Tue Oct 27 11:28:19 2015 +0800

    清理tools目录

commit 2e1d6152b897af33d6a4f2b9a0e60e8f6b9da1bc
Merge: cd724d8 c0d84e3
Author: liu shiwei <liushiwei@gmail.com>
Date:   Tue Oct 27 11:26:40 2015 +0800

    Merge branch 'master' of https://github.com/lshw/loongson1-pmon

commit cd724d8bb2b838b8c4e3fbc97b21d10a0a76a771
Author: liu shiwei <liushiwei@gmail.com>
Date:   Tue Oct 27 11:22:49 2015 +0800

    根据al变量，自动调整mtd的设置，
    al="mtd0" 说明rom开头不包含pmon,

commit 66e11d7d92432f1ffd4d7a8de845270e6d5836e8
Author: liu shiwei <liushiwei@gmail.com>
Date:   Tue Oct 27 11:20:38 2015 +0800

    开启u盘 usb0, sd卡 sdcard0,

commit 9127f4676f00608087b99dfeeb1234bf7a053589
Author: liu shiwei <liushiwei@gmail.com>
Date:   Tue Oct 27 03:16:07 2015 +0000

    clean files

commit c0d84e311f3e1416a5440a511e897967ec805192
Author: liu shiwei <liushiwei@gmail.com>
Date:   Thu Oct 22 21:39:07 2015 +0800

    回车

commit 2cf4fa684517fe0555e6e4e9dea76b06e223dbd8
Author: liu shiwei <liushiwei@gmail.com>
Date:   Thu Oct 22 21:38:14 2015 +0800

    回车

commit a9ea56aeb18384adf83b4a0e9bc4dcde183effdd
Author: liu shiwei <liushiwei@gmail.com>
Date:   Thu Oct 22 19:18:18 2015 +0800

    openloongson 打开sdcard和usb卡功能

commit 5f313878267510ed053108a40f9edd779107186b
Author: liu shiwei <liushiwei@gmail.com>
Date:   Thu Oct 22 18:21:28 2015 +0800

    pmoncfg 安装到/usr/local/bin/
    debian下编译 pmon 和pmoncfg 需要装几个软件

commit 7cd0aa18a41f5eafd304963f57690cadead2e5d2
Author: liu shiwei <liushiwei@gmail.com>
Date:   Thu Oct 15 02:09:45 2015 +0800

    2015-10-13 出厂rom

commit daaed0b923cf7516b01b0f8620c129beb8d5f8f3
Author: liu shiwei <liushiwei@gmail.com>
Date:   Thu Oct 15 02:07:04 2015 +0800

    编译说明

commit f4078b3eb11721475bed6b10834bccb844043ff9
Author: liu shiwei <liushiwei@gmail.com>
Date:   Thu Oct 15 02:03:01 2015 +0800

    2015-10-13

commit 2e42c4c6e3bf3e022ecf9a1f8602887d40f49f05
Author: liu shiwei <liushiwei@gmail.com>
Date:   Thu Oct 15 02:01:53 2015 +0800

    2015-10-13 update

commit d932a96c11d0033c2b906067bb98d29b2d1a6784
Author: liu shiwei <liushiwei@gmail.com>
Date:   Thu Oct 15 01:40:21 2015 +0800

    清理临时文件

commit 866b6319465083b0ab4f992daadd95a95c171849
Author: liu shiwei <liushiwei@gmail.com>
Date:   Thu Oct 15 01:32:05 2015 +0800

    引脚错误，34->39

commit 574f0b86e72b6c52ed1992e642192e352bb4728d
Author: liu shiwei <liushiwei@gmail.com>
Date:   Fri Sep 18 12:36:53 2015 +0800

    gEDA 电路图符号 智龙主板 JP1,JP2

commit 6e5176a1f92db830272e8dfe4f96e21646512224
Author: liu shiwei <liushiwei@gmail.com>
Date:   Wed Jul 22 12:35:14 2015 +0800

    项目导入github

commit b4ca20a20efd4389b7efcbbcc82d494849eaf098
Author: liu shiwei <liushiwei@gmail.com>
Date:   Wed Jul 22 12:34:32 2015 +0800

    1c开龙主板的修改

commit 1a20930669b6d8ba05cf0a95cd83a96236f5ad79
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Fri Apr 18 14:21:59 2014 +0800

    删除一些没用的文件

commit 88e15df2d5fce2e2e7dce3fec3201178cdd8fde7
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Fri Apr 18 12:05:33 2014 +0800

    loongson1:i2c 添加pca953x读设置

commit 2d6fc0b20642dc2b4a947b2f7c3878c0d0e74f72
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Mon Mar 31 19:16:33 2014 +0800

    loongson1a: gamc 修复1a核心板gmac1不能使用的bug,原因是有一引脚用于背光控制

commit 6ba3b09e42ed3a53a958df66299472d144885fca
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Thu Mar 20 16:34:09 2014 +0800

    loongson1a:修正spi和gmac初始化的bug

commit 4a52027daae20a2d762473ea111ace05dca5afed
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Sat Mar 15 13:29:32 2014 +0800

    loongson1:gmac 清理驱动

commit 65be62f7e6dcc1d7e06bee738311ab2a7362d4d1
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Fri Mar 14 08:09:17 2014 +0800

    loongson1:nand 修复内存分配的问题(找不到nand)

commit f232862fcb88e5a7f8d477f35dc78f80af5b813f
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Thu Mar 13 10:34:39 2014 +0800

    loongson1:nand boot更新启动程序

commit 6b6093285f5769c2c0142ae7af9682268a92eb91
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Thu Mar 6 20:21:57 2014 +0800

    修复调整系统初始化顺序后,环境变量中内存大小设置不正确的问题

commit 307f19bb673c696c10a56bf002a366644e7d7b80
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Tue Mar 4 11:06:36 2014 +0800

    loongson1:nand 控制器驱动,申请内存时使地址对齐

commit 87661b4aba6363c8c02bf0658443d9cb2c9a2983
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Tue Mar 4 11:02:03 2014 +0800

    添加对W25Q80 spi nor flash 的支持

commit d08bf99187d821ce69368fac6689454bbd34d9f9
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Tue Mar 4 07:08:48 2014 +0800

    loongson1:nand boot更新驱动,使用分页读取的方式

commit 491bbcbf2c77e6894708a8f55928a132a98bee2f
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Tue Mar 4 07:07:00 2014 +0800

    loongson1:nand boot更新驱动,支持64M sdram?

commit f5870b0d6288e62a06d4ca12f25ee26643a7847b
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Mon Feb 24 23:16:19 2014 +0800

    loongson1c: nand boot更新驱动,nandflash启动及环境变量读写

commit 2308444a071b9406ed8e36787193b4df4c5a46ac
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Tue Feb 18 17:16:54 2014 +0800

    loongson1:ac97 更新驱动,使用单声道录放音

commit 7022483c8f3c9fa6f73a4acb20fe1fd21c511772
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Sat Jan 25 22:38:07 2014 +0800

    lcm:添加st7565点阵lcd驱动,显示图片

commit 452645e630934042e33bd762efc86200a4bbeffc
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Mon Jan 13 20:52:08 2014 +0800

    loongson1: nand 读操作添加column计算

commit 52eb8f934ecda74e84eacb98781772f21df32bce
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Wed Jan 8 20:15:27 2014 +0800

    loongson1:spi 更新spi驱动,提高spiflash读写性能,修正片选的bug

commit b342e5b84425dfaeb10f79f5cdd7ce70dfd27046
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Wed Jan 8 17:52:54 2014 +0800

    修复mtd分区使用spiflash时,读取失败的bug

commit 7591d6f529a7b65d135ee0aa847f67ab7aa4d676
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Mon Jan 6 09:58:35 2014 +0800

    loongson1:更新i2c驱动

commit 32b1a150e0d976d7c88a2028c12a1ec222507d02
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Sat Dec 28 15:30:08 2013 +0800

    loongson1:更新ili9341 lcd控制器驱动;修正gmac读取phy id的判断

commit 805835236030f67a465e7b581d450a011cf8ac6d
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Wed Dec 25 06:29:40 2013 +0800

    gmac:修正探测phy芯片的基地址时可能探测错误的问题

commit 7eef01605bccd9906c89786a56cbaee280d77a32
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Wed Dec 25 06:16:50 2013 +0800

    loongson1:更新nand flash驱动,避免有时读取不到设备的bug;对K9F5608U0D型号读取时采用 延时

commit e44840925e7cd380a02057528d6fad44cb9b886b
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Thu Dec 19 15:35:56 2013 +0800

    修改gmac驱动的phy初始化代码,注意正确设置PHY_BASE的值

commit cdc0f2e952369ccd909a04fa142fb9809344d0e2
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Mon Dec 16 22:06:37 2013 +0800

    屏蔽一些调试用的代码,优化pmon大小

commit d73946b693fe8667e2fbd8d231b421730ef4974d
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Tue Dec 10 04:56:02 2013 +0800

    整理mycmd命令,关闭或删除一些不常用的命令(调试时打开)

commit cd27b15a86372a663a52c7c15eaaf2da56de3341
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Mon Dec 9 16:35:18 2013 +0800

    loongson1:删除汇编启动的串口打印信息

commit b81f7f7b3acf6cb0f9f852fc281ea08e50ff1c6f
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Tue Dec 3 08:33:23 2013 +0800

    loongson1:添加pca953x(i2c)输出gpio设置;添加nt35310复位设置,解决初始化不成功的问题;修改自动加载的延时时间....等等,加快启动速度

commit 5d7964df198a888f555c172fa7c4ba732282f073
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Thu Nov 21 20:41:09 2013 +0800

    修改start.s文件中的蜂鸣器引脚配置

commit 562064e1e2e326570dfde6c7447ed8097a57b088
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Wed Oct 23 09:14:40 2013 +0800

    添加lcd显示屏的DE模式参数

commit 2a61425afa103f5bd2035f82472cbb3407c2e010
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Mon Oct 21 19:25:39 2013 +0800

    修改spi_flash.c驱动,设置片选

commit 903359e60750f5fa02ebf31da812fcede192e015
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Mon Oct 21 17:25:16 2013 +0800

    修改nand控制器时序参数;添加串口复用设置

commit acdcbf9920fc82a43cfe7905e48a9e60db723d6e
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Fri Oct 18 22:48:11 2013 +0800

    添加HX8264 lcd控制器HV mode时序参数

commit 530d7f8b1caff0d0bc496e93657159dbe1f9ab22
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Fri Oct 18 19:25:13 2013 +0800

    添加pca953x(i2c_gpio)初始化函数，用于控制lcd背光等

commit b5d8c74962b9282723e2f961f1853632edaa4b7d
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Sat Oct 12 14:47:21 2013 +0800

    loongson1c:添加cpu窗口修正程序;修改串口复用选择程序

commit a2636f1882131577cf29cf9884b9698b6e18d529
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Mon Sep 30 14:26:42 2013 +0800

    取消autoload时的延时;修复编译时的警告

commit fcd2656f5e5b8b9b48d25320752d543db7f1308a
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Mon Sep 30 10:13:27 2013 +0800

    loongson1:更新lcd驱动,添加行场同步信号的极性设置

commit dcc2af6af04d87440f18e1bede5df3afa5f1e340
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Wed Sep 25 15:57:07 2013 +0800

    loongson1:更新nand驱动,使用高位动态内存分配;增大malloc可分配的内存最大到15MB

commit abf862121e37b3027939925d609b38f4e070a44c
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Wed Sep 25 13:36:37 2013 +0800

    loongson1:更新lcd驱动,使用高位动态内存分配

commit d8aa4a78b0c94b4211360666790b8dab4ee08bcd
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Wed Sep 25 13:28:52 2013 +0800

    loongson1:更新iis驱动测试程序

commit e681e3f99a7ba82159f773fec3a7fc2bfe3ff9f8
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Tue Sep 24 11:03:59 2013 +0800

    loongson1:修改mtd驱动,修复512B page nand的烧录问题

commit de14a3fc822a0b21b4ef648b3a12a087ee0a1d88
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Wed Sep 18 11:07:49 2013 +0800

    loongson1c:添加ls1x_iis录放音测试驱动(uda1342)

commit 05d3271b9fc5b2de31984e19d9661aba610f91ab
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Fri Sep 6 11:13:08 2013 +0800

    loongson1c:更新sdram配置参数

commit 92546306f999a1032ca132e6686c08f771b47a0a
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Thu Sep 5 09:46:44 2013 +0800

    loongson1:更新nandflash驱动,添加dma传输完成判断

commit bdd7311ed89d1eb36fc9e9ea2cfe8fbfbf31dc5f
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Mon Sep 2 13:34:26 2013 +0800

    loongson1:修改ac97测试程序,添加分段读写的函数

commit 7ab3f46712452fb3da6524b933b63b21d2e0f47a
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Fri Aug 30 14:11:21 2013 +0800

    loongson1:更新ac97测试程序

commit c033261365eb2e3575aadcda17cf5f52b0e9ab30
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Thu Aug 22 13:35:03 2013 +0800

    loongson1:修改nandflash驱动,屏蔽不必要的dma_cache操作

commit 2abd60668d1998758c71e9949f6a99b9685508d6
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Tue Aug 20 18:44:17 2013 +0800

    loongson1:修改分配给nandflash的数据缓存大小为10KB

commit 37fbc97a4dd71982fe677254a2412de0fbabca32
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Tue Aug 20 15:14:33 2013 +0800

    loongson1:修改gpio驱动,提供对ls1c的支持

commit ef7f610d44f62b9dd2cf1ba4a2f62aab2d063a99
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Mon Aug 19 19:04:09 2013 +0800

    loongson1c:添加烧录nandflash启动区的程序();添加512B页nandflash驱动的支持

commit 0829a3c0b4aff49fc2c2253cb4d4bea81735cd74
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Mon Aug 12 20:19:19 2013 +0800

    loongson1c:添加nand_boot代码(experiment),只有启动加载代码(1Gb 2Kpage)

commit 19a1ff4240a7bc6473db3d6f368b28ba0085539b
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Mon Aug 12 19:51:54 2013 +0800

    修改nt35310读写延时,及spi接口配置,避免出现初始化失败

commit b21b9df2dfc2a93ca8960d87c9bdae1d30c993a4
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Thu Aug 8 18:31:18 2013 +0800

    修改一些变量类型/read/write函数等系统及的头文件定义,避免重复

commit a6c12cf8298e18c73fdcd8575ce2875576203776
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Tue Aug 6 14:55:01 2013 +0800

    loongson1:更新nandflash驱动(重写),添加对1C的支持(目前使用软件ecc).驱动名ls1x_nand.c

commit 25c79c22b50e09838ba2a9070f8ecb4b4256dc14
Author: root <root@lvling-MS-7680.(none)>
Date:   Fri Aug 2 10:29:15 2013 +0800

    add 1c nand && 32M memory

commit ec35e1015abb91f408c755d6e75cddb573497e2f
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Wed Jul 24 13:48:05 2013 +0800

    loongson1:删除一些没用的驱动文件

commit 7c47fae974f337b074adc200f7e1fab925547f79
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Thu Jul 18 23:17:20 2013 +0800

    loongson1:添加i2c控制器和设备初始化的驱动

commit 79cfda0382d2b2a5247714dd96c954c0216f72e9
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Thu Jul 18 10:41:09 2013 +0800

    修改lcd nandflash sbrk默认分配地址,内核vmlinux默认分配地址为0x80f00000,这样可加载更大的内核

commit f1db02b1f017f347403509ef644db6b5bc4bc71e
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Wed Jul 10 05:18:41 2013 +0800

    ls1b:添加yaoyang考试终端配置文件;修改nt35310驱动初始化

commit 737961e7feb686673b8bb17a804e879dbf579646
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Tue Jul 9 13:56:56 2013 +0800

    添加nt35310 tft lcd driver IC驱动

commit e9a3358ce6aef874420cd2ce36f074a2302da860
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Tue May 14 14:23:46 2013 +0800

    loongson1c:添加对gmac网络驱动的支持;删除usb没用的延时

commit e4d8bba08f220109fe2c25465422e2d87633f0df
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Thu May 9 09:30:59 2013 +0800

    loongson1c:添加启动时串口波特率的计算代码

commit 415909cb85c437e85c8a3e615e37942df7ad923c
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Wed May 8 17:15:09 2013 +0800

    loongson1c:修复直接读取spi flash时返回值不正确的问题;添加通过环境变量修改pll_reg0/1(更改频率)的代码;修改lcd驱动的突发传输长度.

commit 50fefb06e65d0134d17d18b1745c6c38c211bec7
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Tue May 7 17:28:35 2013 +0800

    loongson1:更新lcd驱动的频率计算函数;修复1A的cpu ddr频率值在环境变量的显示错误

commit 575a7057fab7ddf144292014e8e344208f4eafab
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Tue May 7 11:09:47 2013 +0800

    loongson1c:添加lcd的时钟分频设置;完善系统的设置及调用

commit 599ea31f2bb805341128023093fa3694a3977a99
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Mon May 6 13:57:10 2013 +0800

    loongson1c:修正部分环境变量设置不正确的问题

commit 8b35bbcbb93bd38912a644efb604c4e1346f3948
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Sun May 5 15:26:04 2013 +0800

    修正使用32MB以下内存时,快速fat文件格式读取的错误(load)

commit 6851900ca48b21f408309922c447d9a42eb98f33
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Sat May 4 18:36:27 2013 +0800

    loongson1:添加对1C CPU的支持

commit 830ccdb31937a33a9c840a94a5d3f51dfc63da1e
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Mon Apr 15 10:31:34 2013 +0800

    添加nand flash复用方式设置

commit 278a03d66fbc1cf496713c1aa55a455a4c66bfcf
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Tue Apr 9 17:27:21 2013 +0800

    gmac:修复编译时可能出现的类型引用错误

commit 07e60a63771e11bfcaec0496d062af0b3e007416
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Mon Apr 1 18:03:47 2013 +0800

    添加对W25Q64 SPI Flash分区的支持

commit 142a26253fcee01e448cdd688fc04c7447c6f7c0
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Fri Mar 29 22:24:24 2013 +0800

    loongson1:重命名lcd控制器驱动的c文件,并放到对应的dev目录

commit c23481ffba799d1be5695162eb00e8f17ac53398
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Fri Mar 29 21:52:39 2013 +0800

    loongson1:删除一些没用文件

commit bf2e627dd15101a3a6bf9d2affc664c46260f966
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Fri Mar 29 21:35:17 2013 +0800

    添加按键轮询测试程序

commit 6a8382fabddb7893a9795ddbc5da1fcc71a1aca8
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Tue Mar 19 13:32:32 2013 +0800

    loongson1:更新spi_sdcard驱动;通过配置文件选择spi控制器,片选和时钟频率

commit 9565ec03a51aa6ab637dcba135a218ffdbe43fa8
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Thu Mar 7 14:03:44 2013 +0800

    loongson1a:单独设置gpu时钟频率为200MHz,提高其性能

commit 8db10682c136903ade959a0698a2e3ecb36ea2f0
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Thu Feb 28 19:08:46 2013 +0800

    添加1920x1080@60Hz显示分辨率的支持

commit c7ffa4f472355f60999f3f7219adc44fac2d47ed
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Thu Feb 28 14:46:14 2013 +0800

    更新ac97驱动,更正驱动中的一些错误与多余的程序,同时使驱动易于阅读与维护

commit 31e87e920f25975949209e6ae5ffadef7efa5907
Author: linxiyuan <linxiyuan-gz@loongson.cn>
Date:   Tue Feb 26 21:45:57 2013 +0800

    fixup to support heigh capacity SDcard. Test 4G, 16G is OK.

commit ad1c26f0e9b9e331ac0b826e40013307b0637aa3
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Wed Feb 13 10:44:10 2013 +0800

    删除kbd.c驱动中的打印信息

commit ade764101525d99a77f00b7736176e5b68c4fe35
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Thu Feb 7 16:42:14 2013 +0800

    loongson1a:提高GPU的工作频率,修正启动时有时出现黑屏的bug
    
    GPU频率不低于LCD和VGA频率?使GPU倍频比LCD和VGA大2,目前测试还没出现黑屏的现象

commit 74fe4f7361d7bedcb014d528e9298d8ebe430422
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Tue Jan 22 16:50:40 2013 +0800

    修改ili9341 lcd控制器spi片选引脚

commit 745ce23497db36137b61dbc8df93d18abd021c7a
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Thu Jan 17 21:02:52 2013 +0800

    修改ls1a caclulatefreq()像素时钟计算函数函数
    
    提高像素时钟计算的准确度和低分辨率 时的准确度;修改背光设置时段,可避免初始化lcd控制器时屏幕闪烁

commit 35e759e7f3085aa5377919a4c191d7fcf73f073c
Author: linxiyuan <linxiyuan-gz@loongson.cn>
Date:   Tue Jan 15 21:46:52 2013 +0800

    LS1A: add acpi_test.

commit d11fd8ee6d3850e04d8095ff8ce45a8aa7a77801
Author: linxiyuan <linxiyuan-gz@loongson.cn>
Date:   Tue Jan 15 15:03:50 2013 +0800

    LS1A: fixup GMAC1'phy can't initial when set LCD's Backlight.

commit 6f0af3d27d1c382d37a91b342a309b7377fb4cf6
Author: linxiyuan <linxiyuan-gz@loongson.cn>
Date:   Tue Jan 15 13:46:29 2013 +0800

    LS1A: add PS2-keyboard test, and add color for test menu.

commit 52695dd8b0983ebd1388a72d6d6c39045c07e831
Author: linxiyuan <linxiyuan-gz@loongson.cn>
Date:   Tue Jan 15 10:51:46 2013 +0800

    LS1A: add can selftest.

commit f80b17d645698ba99c59b2990b5be4725464c6a0
Author: linxiyuan <linxiyuan-gz@loongson.cn>
Date:   Mon Jan 14 15:32:02 2013 +0800

    LS1A: change setting for new core board.

commit 631225c117cf00ad12ee01cbd67f084d2bcc1161
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Thu Jan 10 23:15:51 2013 +0800

    修改输入命令行最大长度限制为256个字符

commit 909eab3f213a6ed402f614bb37b302a58e90a61f
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Thu Jan 10 18:55:16 2013 +0800

    删除启动时的lcd复位程序;使能cpu cache

commit 55718d6430751cdd144d75bbd41b4737dd3dd00d
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Wed Jan 9 17:56:52 2013 +0800

    ls1a:添加lcd背光控制;修改晶振频率为33MHz

commit f4f2abd5d0c27dc875be8c29a6382c09a912ca67
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Sat Jan 5 17:01:02 2013 +0800

    increase fatfs read speed.

commit 4ee9cc368b40235077cdaa0601de58812e3d20f9
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Sat Jan 5 14:14:38 2013 +0800

    修正核心板在使用vga模式时,串口出现乱码和死机的问题

commit 66ef986c82728b7a0179766c8f4e2eb6a90a3417
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Sat Jan 5 14:07:51 2013 +0800

    添加使能usb控制器在使用ehci协议时

commit 7fd24aaa030bd785095cffcb3a07c93546c8b45c
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Fri Jan 4 16:25:21 2013 +0800

    修复lcd驱动使用24bpp和32bpp时串口5打印乱码的问题(被复用)

commit 8e7b8dcd24a86a629c420c2b284983ea6e819311
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Tue Dec 18 14:51:54 2012 +0800

    ls1a:修改cpu窗口配置
    
    不合适的窗口配置会造成cpu死机,非内存地址需要把mmap[5] -> block trans enable位关闭

commit 808b6bf515e8e6aa6306f1bdd7e359a5f67c9f37
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Thu Dec 6 16:43:00 2012 +0800

    ls1a:修改gpu命令缓存地址为0xa2800000,避免冲突

commit f6c651109f472cef86a18c285f4da9df481d2051
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Fri Nov 30 13:41:09 2012 +0800

    修改lcd显存地址为0xa2a000,避免和nand flash内存地址及其他设备内存冲突

commit 516722095bd7fe950695dbe47dde1b8a1855ba7b
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Fri Nov 30 11:03:26 2012 +0800

    ls1a gpu:删除display.h无用头文件

commit 93a4b63008f609b25626074e2813c7e9a2de3c90
Author: linxiyuan <linxiyuan-gz@loongson.cn>
Date:   Thu Nov 29 20:40:35 2012 +0800

    LS1A-cloud: modify dc's base address for conflict with nandflash when set 1440x900.

commit 65f85ab116fea734a9569df494af621bad7a0320
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Thu Nov 29 14:21:55 2012 +0800

    ls1a gpu添加rectfill测试代码

commit bd7d52043906d99e2d708fac80f6536a687f25b1
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Thu Nov 29 11:39:05 2012 +0800

    添加BitBlit测试和Rotation测试代码

commit 6761c83a93a4bbfa2e487ac4e70221dd08ccfdfa
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Wed Nov 28 14:54:19 2012 +0800

    修改ls1b cpu窗口配置和工作频率
    
    cpu产生的地址如果是非ddr访问要把block trans关闭();修改默认工作频率为cpu:220MHz ddr:165MHz

commit a31c3806df3e5ca9dd44c2df0bf416b87bff7e43
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Tue Nov 27 23:37:48 2012 +0800

    添加ILI9341 TFT LCD控制器的驱动(RGB+3line接口240x320)

commit 648b4564ba608718545017a1597098e1b88ad82d
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Sun Nov 25 22:04:26 2012 +0800

    修改LCD驱动
    
    删除一些无用的代码,修改1b计算lcd分频的方法,修正使能lcd数据输出时寄存器的bug

commit cead025be964df9bdb820726fe4e896d3bb34c33
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Wed Nov 21 23:42:36 2012 +0800

    修复不编译usb文件时出现的编译错误(缺少devfs文件)

commit 3bf10ae8d894671606ded55bea11af84b8009a16
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Mon Nov 19 21:39:47 2012 +0800

    添加bmp图像测试函数
    
    用于加载自定义的bmp图像到显示缓冲区,或在加载自定义开机图片

commit 8ca7b4d38d9ed0954c23f045913e4befa20fca5e
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Thu Nov 15 14:30:13 2012 +0800

    ls1a:修改ddr2内存配置
    
    使用33MHz晶振,最高稳定频率CPU:297MHz DDR:165MHz. 25MHz晶振,最高稳定频率CPU:275MHz DDR:150MHz

commit c14f11450308ae7ac5d230c94382bb85899dcb97
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Tue Nov 6 15:43:36 2012 +0800

    添加内存EIGHT_BANK_MODE定义(内存颗粒的8bank或4bank选择)
    
    定义在配置文件中,请选择对应开发板的配置文件(配置文件名与使用的板对应,如ls1b是默认配置文件,对应1b开发板)
    
    如ls1b.core配置文件对应1B核心板,请认真区分
    
    内存颗粒有8bank和4bank的区分，请认真看清使用的内存颗粒的bank数，请认真参考内存手册

commit 65cd21b5e45187fb51633c3d10347783e1e5dd4c
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Tue Nov 6 11:12:30 2012 +0800

    修改tgt_machdep.c文件中的Flash操作函数,使1A的LPC Flash可以被正确访问
    
    注意：1A LPC Flash启动地址映射为0xbfc80000,需要把spi flash禁用,使用LPC Flash需要修改的文件为pflash_tgt.h start.s和ls1a files.LS1X配置文件

commit b3d5d6e878e1fdd8a81d724cea29ae56fb73d5e5
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Thu Nov 1 17:36:15 2012 +0800

    修正执行fl_verify_device()函数进行flash校验错误的问题,原因是执行fl_devident函数时要求填充一个指向fl_map结构体的指针

commit 475520431a623110208ba831a166fe3455bb1891
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Tue Oct 30 14:11:15 2012 +0800

    ls1a:增加LPC Flash支持,目前只能工作在只读方式,需要添加Write Locked解锁函数,但1A的LPC memory地址映射不详

commit ab8a73c3c95b372695aac27aac283cab965d2be1
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Thu Oct 25 15:26:58 2012 +0800

    ls1b:修改cpu窗口配置,修正部分地址读导致死机的问题

commit fcf386e39c2e05ba289859b36bae3ec3be5d0a0e
Author: linxiyuan <linxiyuan-gz@loongson.cn>
Date:   Thu Oct 25 14:12:56 2012 +0800

    ls1a: fixup acpi stop at startup.

commit b16b5580a097f5e079894399f08f0bc3f34b0b90
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Thu Oct 11 18:47:12 2012 +0800

    添加ls1b cpu窗口配置,打开gmac

commit 04bdb6a5d32c5728ab2a44f0726002f052da1b33
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Thu Oct 11 11:19:45 2012 +0800

    ads7846驱动读取坐标值时添加适当延时

commit 8aff082a882507a3273583e1da3ff9b44d493656
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Fri Sep 28 17:49:49 2012 +0800

    ls1a:修改pci_machdep.c中pci_local_mem_pci_base的值(pci和usb共用时会死机)

commit 7b9faa42322f6fd42f3cfac4162d17ec63bbc6e6
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Thu Sep 20 15:53:55 2012 +0800

    ls1a:使能1a核心板的pci控制器,默认不使用pci,问题是会导致usb控制器不能使用,需要找到原因

commit 2c1e320814231f0301e03af144f6bb6e748c59d7
Author: linxiyuan <linxiyuan-gz@loongson.cn>
Date:   Thu Sep 6 19:52:42 2012 +0800

    add timing configure for ls1a sata.

commit b4e923c4ed58b23515971cfb925fea0400ee1859
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Thu Sep 6 15:37:51 2012 +0800

    修正使用ejtag烧写ls1a板后,频率显示不正确的问题(pll_reg0)

commit b099990211226ab26310596f41010870d3dd3f93
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Thu Sep 6 10:54:14 2012 +0800

    修改GMAC0和GMAC1网络控制器引脚复用及百兆和千兆模式的配置选项

commit 2f54efcd0615847934b5949c014d6dc419a33795
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Wed Sep 5 09:26:11 2012 +0800

    ls1a:修改内存默认配置文件为samsung-CL3

commit 7099fa2380073a2d97b41ef2816267a21e3fb222
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Tue Sep 4 15:57:15 2012 +0800

    ls1a:修改lcd驱动支持低分辨率的显示屏

commit 0c01fd54d3e67cdd51bebe5476a1f62d34ea58cb
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Mon Sep 3 15:25:28 2012 +0800

    gmac:在千兆模式时屏蔽synopGMAC_linux_cable_unplug_function函数,该函数会不断执行影响系统性能.

commit 17786429307959458da04912f1b925c773661468
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Tue Aug 28 22:22:14 2012 +0800

    添加JBT6K74 TFT LCD(TD028TTEC1)控制器驱动.

commit 5de4218985b248072b73df9677965b3ed0831e7b
Author: linxiyuan <linxiyuan-gz@loongson.cn>
Date:   Mon Aug 27 21:04:31 2012 +0800

    add support for each port sata disk to load for ls1a.

commit 68dbffd4f7e0970685aa6ac64bcc8760815c98b8
Author: linxiyuan <linxiyuan-gz@loongson.cn>
Date:   Mon Aug 27 10:18:58 2012 +0800

    add single test for display all white color.

commit a17d068414c13b10f81b05a89063ff8ba377d9f4
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Fri Aug 24 16:16:00 2012 +0800

    修改1bcore默认串口地址

commit aec53d426442ac2c4dfc0400c3e6f923a6206842
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Fri Aug 24 15:45:19 2012 +0800

    修改1b默认频率设置.

commit 65185f9a2a74e277e3d52cc0a4aa4060c5873006
Author: linxiyuan <linxiyuan-gz@loongson.cn>
Date:   Thu Aug 23 11:41:47 2012 +0800

    init gpio0 output heigh to disable system reset for 1A-cloud.

commit 7b4f738298f4c8b18fdd93559d6dcfbf098bd3c4
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Sat Aug 18 19:50:32 2012 +0800

    添加使用25MHz晶振时,vga接口可正常显示的时序.

commit be807ff2365d0284818fb1281b4b47cc1875aa02
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Thu Aug 16 20:23:17 2012 +0800

    添加ls1a gpio复位代码.

commit 3e395191a4056509c56c383b7e78624926042779
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Wed Aug 15 14:27:33 2012 +0800

    修改spi控制器的分频系数为4,200Mhz ddr频率下,分频系数为2时1A云终端修改spiflash时出问题.

commit f91fca33615c9ba31ebc4d56d1a95f4209bdcc37
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Mon Jul 30 11:26:26 2012 +0800

    取消lcd驱动的动态内存分配.

commit 52a7d6c968965567156a4c9790344699e2160824
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Thu Jul 26 15:33:32 2012 +0800

    修改lcd驱动使用动态分配内存，nand驱动使用动态内存分配有问题.

commit 07ceca7bd6e9ab5c75cb38c24658b42f034fc94c
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Mon Jul 23 10:42:25 2012 +0800

    修改ls1b nand驱动，使用动态分配内存.

commit c863071ecd05802a2f17860f153fc776377aa25e
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Fri Jul 20 16:40:55 2012 +0800

    更新gpu驱动.

commit fac9b4b8f02aa95629c09903af7345832d1754c2
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Wed Jul 18 21:14:52 2012 +0800

    使能ls1a gpu.

commit 134533c79edae39558bc04c8b77d490c267cd00c
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Wed Jul 18 16:21:23 2012 +0800

    修复dc.c编译错误.

commit b6fadeaec5cd736d5c7cbeac54bad4cd75372011
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Wed Jul 18 16:12:51 2012 +0800

    更新ls1b lcd驱动,修正高频率时lcd刷新率不正确的问题.

commit 4be8f4994cfc6123cf4cb6558a69523f96677b1d
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Mon Jul 16 14:56:45 2012 +0800

    更新lcd驱动dc.c,可能由于PIX_clk2控制器设置不当导致的屏幕闪烁(长时间重启测试).

commit 9c32b8ba2fdcb267c9b0c069718aa12314616682
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Mon Jul 16 13:50:22 2012 +0800

    启动时默认关闭ls1b的USB GAMC0 GMAC1(ls1a关闭sata gpu usb gmac0/1),执行对应初始化函数时再使能相应模块.

commit 1fd25cd62daa7b39028811da9ff1fce0ef2b350d
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Fri Jul 13 15:05:35 2012 +0800

    更新内存参数.

commit 6d14634777d39df7780d32d41ef28feef2083af1
Author: tanghaifeng <root@dmf-virtual-machine.(none)>
Date:   Mon Jul 9 22:22:31 2012 +0800

    修改ddr内存配置为CL=3.

commit 9aaf93a132cd041771fc2f7dde015ef2489ed364
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Thu Jul 5 16:05:44 2012 +0800

    添加uart波特率支持.

commit 92a4770ff09b573398822e8790ce8081ed6b0a20
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Sat Jun 30 21:25:34 2012 +0800

    更新SPI Flash驱动,修正一些小问题.

commit 7b76db4872ddc1e50719c848200c4ad01f9c4db3
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Sat Jun 30 18:39:25 2012 +0800

    更新SPI Flash驱动,解决大于8MB时不能使用快速读取的错误;使能1A/B SPI Flsh的双I/O模式.

commit f3e284b2fb389c19d55c80bcb6cfa6d0f0635fc9
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Fri Jun 29 18:39:15 2012 +0800

    添加winb25Q128 SPI Flash驱动支持.

commit 609051f62ae2adc4dbdc0db773bf840d77954ea7
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Thu Jun 21 16:36:05 2012 +0800

    添加DDR2 SDRAM PAD驱动配置设置的代码,增加内存稳定性.

commit 5c6f8b3c603ffb95fe35d4f8f7c8b72c75508d5a
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Tue Jun 19 12:01:53 2012 +0800

    修改xres,yres,depth env.

commit cda1a06a8f0a9eccee0c1794c4e9f68024b58ab2
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Mon Jun 18 10:17:02 2012 +0800

    ls1a修正高分辨率时vga显示闪烁的问题.

commit 556a95a72634e0639f707792863fd428a2a177a4
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Fri Jun 15 18:02:47 2012 +0800

    更新ls1a内存配置.

commit 61c4367861144163145705701b9bb23cebd28884
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Thu Jun 14 20:50:50 2012 +0800

    修改ls1a NAND flash gpio复用配置.

commit fe09615e38e68abccdf76f91d7604e0ec7794ff4
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Thu Jun 14 17:12:26 2012 +0800

    添加ls1a云终端编译配置文件.

commit dff53cc97b258d157bc0cd0279137e3c86d36f71
Author: linxiyuan <linxiyuan-gz@loongson.cn>
Date:   Tue Jun 12 23:09:11 2012 +0800

    change gpio config for nandflash && change nandflash's address reg

commit 6fc4a864c1aaac7e2efe86f80805de3f7373e31f
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Tue Jun 12 19:01:28 2012 +0800

    更新内存配置.

commit 5f077858e58f3132c18a1f32c59ea68ff7ebb78f
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Tue Jun 12 10:26:39 2012 +0800

    更新start.S文件.

commit 05f81f66ec759a591d759d924ad0d92a048c49ef
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Mon Jun 11 14:07:51 2012 +0800

    更新tgt_machdep.c文件.

commit 5c662088114c7dffac70e3efde5960785f174f2a
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Thu Jun 7 16:58:40 2012 +0800

    更新内存配置.

commit 04691ddbdc85286fc0491fa3f60dc710ab3a1bf4
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Mon Jun 4 20:09:27 2012 +0800

    修正lcd 1440x900分辨率的刷新频率设置.

commit 4cd0f691912d8f9e27496cc2b6ecdd3ec61254f9
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Mon Jun 4 01:11:00 2012 +0800

    修正lcd参数设置的错误.

commit 4af0ba794690e9e9454172162e7b97acbcbaf6e2
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Fri Jun 1 10:43:55 2012 +0800

    添加1B(core)核心板PMON编译和配置文件.

commit 02434003af2302c83bae791859a5cb8360e45a14
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Thu May 31 17:30:12 2012 +0800

    修改内存配置参数,减少CL延迟.

commit a02936dca859223e3bb01a843d9b217070d50e79
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Mon May 28 21:50:55 2012 +0800

    使能ls1a的vga输出.

commit 25f3480fefeb006f23766fe1b5038eb330b741a1
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Sat May 26 22:58:09 2012 +0800

    修改设置pll的环境变量(由于0xbfe78030寄存器读取不正确).

commit 3888a8041886f7391f34329a02ca5a71ca314f3e
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Sat May 26 16:39:56 2012 +0800

    修改内存模式配置和GMAC模式配置.

commit 2d500da63a09a9cecade0a5dc5ef92d0bd54d9be
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Sat May 26 10:47:26 2012 +0800

    修改reboot命令,支持ls1a reboot.

commit b5ca9ffc7c8b288c4254a280b9fcfabc38959079
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Fri May 25 23:34:22 2012 +0800

    修改ls1a默认配置文件,添加usb ohci驱动支持.

commit 68503377bb9b3859cbf2615dec61b8e84f2a9fdf
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Fri May 25 23:09:28 2012 +0800

    添加ls1a配置文件.

commit 720f73472cf6cb0c01ce5257a5e6a965e0bd0d7f
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Fri May 25 22:28:39 2012 +0800

    添加ls1a ddr2内存配置文件.

commit f8ca1b2fd34e8e6541a02ec390c4e714e9370f62
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Fri May 25 21:26:16 2012 +0800

    修正kbd.h中LS1ASOC平台定义的错误.

commit 278638e88eb708270f07c7c4a36f6bcabb910e7f
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Fri May 25 19:23:39 2012 +0800

    添加nor flash分区的条件编译选项.

commit f7c39060b451d3d22f3b05c0341ac46508aa1771
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Fri May 25 18:55:20 2012 +0800

    添加蜂鸣器编译选项.

commit 6826c50656c159e91e36092f67b7073426315ece
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Fri May 25 18:04:03 2012 +0800

    fix tcp for gcc 4.3 compile.

commit 3798c59500948dca98d6b8f33c916db9e398fdc2
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Fri May 25 17:31:10 2012 +0800

    重命名LS1x目录名和文件名.

commit 8dfea4ccb684802a8935ea66613d0078ce644fd2
Author: linxiyuan <linxiyuan-gz@loongson.cn>
Date:   Fri May 18 13:52:36 2012 +0800

    modify cloud-terminal test, and IPcamera's com1 base

commit 4f9d6e5530db62dc4be5ba97be48c8453e5f12d7
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Thu May 17 22:17:44 2012 +0800

    修正使用32bit内存时,由于变量定义错误导致的0xbfd00424寄存器赋值错误.

commit f1ef2526c691321c7a9363ebf4e139d2ad2c688e
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Fri May 4 11:58:26 2012 +0800

    修正vga显示的刷新时序.

commit d02d0488dd507faae626a21ad53180a2ff6d6e1f
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Fri May 4 11:18:47 2012 +0800

    修改vga显示的刷新率和内存分频值.

commit 524694da4656a5be33de8d357c1df902120edb11
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Thu May 3 16:51:58 2012 +0800

    修改晶振输入的默认频率为33000000Hz.

commit 14de3095128cfd995b973575d75a4d9280ceb0d8
Merge: b7e8df8 fe41610
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Fri Apr 27 15:21:30 2012 +0800

    Merge branch 'master' of 192.168.1.48:1B-PMON-BSP

commit b7e8df85f23483e74b58e10f5ab94ba241e06cb0
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Fri Apr 27 15:20:45 2012 +0800

    ls1b添加对不同频率外部晶振的支持,通过修改配置文件的APB_CLK定义来设置.

commit fe41610d16ae02c73b62bb86568c635c28376f61
Author: linxiyuan <linxiyuan-gz@loongson.cn>
Date:   Wed Apr 25 17:41:08 2012 +0800

    fixup error for last commit to git

commit 050f9af37569f3d9c2df5b456e1d5274023e380f
Author: linxiyuan <linxiyuan-gz@loongson.cn>
Date:   Wed Apr 25 15:25:10 2012 +0800

    add update kernel && filesystem to test command for cloud-terminal

commit 522c4e4bdf397a87f932a2434b749b56dfe67a2e
Author: linxiyuan <linxiyuan-gz@loongson.cn>
Date:   Sat Apr 21 15:43:21 2012 +0800

    add detect uart3'pin to checkout to differenct mode for cloud-terminal

commit 9193c7ea5761fc3bbb370d46b6ab8f4fa8de5971
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Thu Apr 19 11:51:34 2012 +0800

    添加sdcard驱动的SPI1控制器支持.

commit b5a073eda926ae4aca415ddc7c160723412dc721
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Tue Apr 17 17:12:30 2012 +0800

    修改USB复位代码到usb控制器初始化函数,屏蔽非1B的执行代码,不必要的打印信息.

commit e4ed95002ab1a75c4fe4d384e6f206bf665c96f6
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Mon Apr 16 22:46:16 2012 +0800

    修改spi控制器的分频系数,提高速度,需要根据具体spi flash确定最高运行频率.

commit 788878df3957a2f613948daad57ec817fe0aca44
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Mon Apr 16 16:44:23 2012 +0800

    添加winbond W25Q64DW SPI Flash的快速读写支持.

commit 9a150786d2778c8a074554dc4eb4c2ff683df87c
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Mon Apr 16 15:04:52 2012 +0800

    lcd:添加NT39016D TFT LCD IC 控制器的支持(时序).

commit e8d315f0fd10d6f42a7aba2aee8eeb27f9ea8c35
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Fri Apr 13 14:33:14 2012 +0800

    sdcard:更新sdcard驱动,提高文件加载速度.

commit f166577409289f9ef7374db22c6dc9814a348539
Author: linxiyuan <linxiyuan-gz@loongson.cn>
Date:   Wed Apr 11 20:09:57 2012 +0800

    modify some file with error for new cross-tool

commit 6ed2c0f8e375b477af82845f9885aa91a915378d
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Tue Apr 10 15:45:36 2012 +0800

    sdcard:增加尝试次数,解决SD卡初始化失败的问题.

commit 515d1d9ce0513193b96061855053dce35e5ab0b9
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Mon Apr 9 14:05:04 2012 +0800

    gmac:修改synop_handle_transmit_over() synop_handle_received_data()函数,提高执行效率减少网络延迟.

commit 88d7984edac65c0396d72c75d19ab51c3c31594b
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Mon Apr 9 11:25:50 2012 +0800

    remove the /sys/dev/gmac-old.

commit 003e5ec5985fa6f5aed44acd61d579b6eada52b3
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Mon Apr 9 11:16:59 2012 +0800

    gmac:修改synopGMAC_intr_handler()函数,提高执行效率减少网络延迟.

commit fceaaa4d5baa2275742dd8fc6f22998017489f35
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Sat Apr 7 17:51:05 2012 +0800

    gmac:暂时屏蔽gmac中断处理程序中的synopGMAC_linux_cable_unplug_function()函数的执行来提高网络速度,减少网络延迟.

commit 0df0e354ddfb0b9654a28b4ee64dc950d3e614c2
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Sat Apr 7 17:32:59 2012 +0800

    gmac:修改GmiiCsrClk赋值为GmiiCsrClk2,减少网络延迟

commit b3c609a5a4fa176230ea4fe804986cdabb5259ec
Author: linxiyuan <linxiyuan-gz@loongson.cn>
Date:   Thu Apr 5 08:30:18 2012 +0800

    add support for 16G sdcard, fixup for read nandflash ID

commit e63f4c587d154ddfb5b7479b6729ba32d3eab049
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Sat Mar 31 10:53:09 2012 +0800

    fix fb last line clear.

commit 7c1806714ae300f3667b6e9a7e4241a45dc4464f
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Sat Mar 31 10:25:13 2012 +0800

    fix ls232 cache config.

commit debb8ae2270c0392f3a65900b60d51b51a2d33f8
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Tue Mar 20 10:23:31 2012 +0800

    修复gpio函数定义和引用时的错误.

commit 3d3c8c703c7398d048bdf1b6d936eda0209b8f00
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Mon Mar 19 15:04:16 2012 +0800

    添加MG323 GSM模块复位和启动控制代码,使上电后启动.

commit b85533775af122ef4421062a48f6200a0d4db6dd
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Sat Mar 17 16:28:07 2012 +0800

    更新ili9341驱动.

commit 3d9c6f0718bfe63f579d50418c798073b660e05c
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Sat Mar 17 15:05:39 2012 +0800

    添加ili9341 tft lcd 控制器驱动.

commit 6a819b10fd64a4a188dfdf2d3938d56b8d32ac19
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Thu Mar 15 16:59:36 2012 +0800

    修改ZIGBEE_POWER引脚错误定义.

commit a7a8032fa76df734bdcc49b134b33a537cfe0f0f
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Thu Mar 15 16:56:15 2012 +0800

    zigbee:拉高GPIO52引脚 使能ZIGBEE模块供电,修改ls1b.Zigbee默认配置文件.

commit 6d85dfcbbb89b15a8a3edb3a814c2534c149e223
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Thu Mar 15 16:46:44 2012 +0800

    添加gpio.c文件,操作gpio函数.

commit e11a782c7b756bee2a002a08b65fa5ee25a56f1e
Author: linxiyuan <linxiyuan-gz@loongson.cn>
Date:   Mon Mar 5 17:14:41 2012 +0800

    add write kernel-ramdisk to nandflash for production

commit a15574d9b30ce6e3f2640469aafe805cff6ff73f
Author: linxiyuan <linxiyuan-gz@loongson.cn>
Date:   Mon Mar 5 15:21:14 2012 +0800

    add could-terminal config

commit 8222368a6cbf43991a5adff866805c4e10b8205b
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Mon Feb 27 10:13:30 2012 +0800

    change max usb storage to 5.

commit 2dc7ea338e49622241762019cd3c0048812ca1be
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Fri Feb 24 18:01:02 2012 +0800

    修改IPCamera默认配置文件,取消framebuffer编译选项,取消lcd显示.

commit cb438ad50096eb7286be690f12e9191937614f69
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Fri Feb 24 17:45:43 2012 +0800

    修改IPCamera默认配置文件,取消网络GMAC驱动编译选项.对部分系统文件作了改动.

commit ea43bde74c4a5003f2680cda3d07efdd3f331d2d
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Thu Feb 23 14:07:01 2012 +0800

    添加1B Zigbee PMON配置文件.

commit 3e960b09118e46dd0a0f12534d15d21cb8dddd2c
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Thu Feb 23 13:55:44 2012 +0800

    修改内存大小配置.

commit 355af1c7c5e0c8927549427412a5f4ac85083a1c
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Thu Feb 23 10:24:18 2012 +0800

    add xres,yres,depth env.

commit 88bcfd2cdfb641ddeb98653665e443899a329916
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Wed Feb 22 16:14:25 2012 +0800

    修改IPCamera默认配置文件,取消NAND Flash编译选项,添加NOR Flash分区选项.

commit c4615f7e20fb0658c72c292634956b1315535079
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Wed Feb 22 09:52:16 2012 +0800

    添加1B云终端PMON配置文件.

commit ae1a4627f1a9fb8f65c6a69e7a650fc973322f4c
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Tue Feb 21 22:07:15 2012 +0800

    添加1B IPCamera PMON配置文件.

commit 89de14f1b142a5cc352356db958ccf61138c416b
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Mon Feb 20 09:47:29 2012 +0800

    修改vga800x600的刷新率,设定在60Hz,会降低CPU和内存工作频率><

commit f97bb12474f46ace7ecc9b3c5ddf1bce15cabf34
Author: tanghaifeng <tanghaifeng-gz@loongson.cn>
Date:   Sun Feb 19 23:21:35 2012 +0800

    修改LCD驱动(dc.c).使用vga显示时内存工作在合适的值.

commit d757c7cce8e0885f2c00c4b762cccd53f19ba6f8
Author: xuhongmeng <xuhongmeng-gz@loongson.cn>
Date:   Sat Feb 18 16:50:22 2012 +0800

    更新LCD驱动(dc.c).修改分频和倍频寄存器值(0xbfe78034 0xbfe78030),使vga刷新率等于60Hz,符合VESA监视器的时序标准.

commit 2cd76b0f455121b15af178067a2b3deb14f1c052
Author: 唐海峰 <tanghaifeng-gz@loongson.cn>
Date:   Sun Feb 5 22:47:53 2012 +0800

    fix cfb draw unaligned address for some resolution.修改LCD控制器默认刷新频率

commit ecbee203b9f7aa0733ec2e89cc24a85f5a0cf2dd
Author: 唐海峰 <tanghaifeng-gz@loongson.cn>
Date:   Sun Feb 5 14:58:21 2012 +0800

    更新I2C驱动

commit bdd038e8903e2225e51ca73c6cb2b4a1c3d2497b
Author: 唐海峰 <tanghaifeng-gz@loongson.cn>
Date:   Sun Feb 5 13:47:49 2012 +0800

    add example hello1.

commit bb8e668058257d0a0c67d164112b712dd37a1e31
Author: 唐海峰 <tanghaifeng-gz@loongson.cn>
Date:   Wed Jan 18 17:19:03 2012 +0800

    修改GMAC1初始化时GPIO的配置方式

commit 8e4c41c1c01e19b62eb156ae34b01b37b586e4be
Author: 唐海峰 <tanghaifeng-gz@loongson.cn>
Date:   Wed Jan 18 14:37:27 2012 +0800

    ls1b:默认打开软件光标选项

commit 54f8e2e03ee6b28cec62917903561f39b7e75bc5
Author: root <root@thf-HuronRiver-Platform.(none)>
Date:   Mon Jan 16 14:34:31 2012 +0800

    更新LCD驱动 添加对LCD转VGA的支持 添加软件光标的支持

commit 2367da41100623c34daafd2d9ef48ac5296d102d
Author: 唐海峰 <tanghaifeng-gz@loongson.cn>
Date:   Fri Jan 13 14:59:13 2012 +0800

    usb ohci: increase usb timout delay.

commit 27ae37bd8f02445810bc567c62aa3decbaf58462
Author: 唐海峰 <tanghaifeng-gz@loongson.cn>
Date:   Fri Jan 13 13:30:51 2012 +0800

    修改cfb_console.c格式

commit 3a5e40505b6923c321ee1c5aff48a576bf678c79
Author: 唐海峰 <tanghaifeng-gz@loongson.cn>
Date:   Fri Jan 13 11:27:18 2012 +0800

    新开发板PMON 16bit 4bank内存

commit 0fd71c9002dc1bf6116f9eedf7bd9753ea58d0f6
Author: tanghaifeng <tanghaifeng@localhost.localdomain>
Date:   Fri Nov 25 16:32:33 2011 +0800

    降低内存频率

commit 1511b1fce822fd49f9e7117122e0dab3a7ce0e70
Author: tanghaifeng <tanghaifeng@localhost.localdomain>
Date:   Fri Nov 25 15:04:12 2011 +0800

    降低内存频率

commit b881e38d021ac10d894c971a1b468438ff6d00b9
Author: tanghaifeng <tanghaifeng@localhost.localdomain>
Date:   Fri Nov 25 10:21:01 2011 +0800

    修改内存配置文件/Targets/LS1B/ls1b/ddr2fconfig.S  提高系统稳定性

commit f9559fddcb86954fbb8c94474b3cfa97d384926f
Author: tanghaifeng <tanghaifeng@localhost.localdomain>
Date:   Fri Nov 11 16:05:14 2011 +0800

    修改/Targets/LS1B/ls1b/start.S文件，更改内存分频值为5分频，提高稳定性

commit daa2d7c93c9377f20606c64534a84408d128be91
Author: tanghaifeng <tanghaifeng@localhost.localdomain>
Date:   Thu Nov 10 15:41:42 2011 +0800

    取消旧的版本信息获取和打印信息，修改/conf/newvers.sh脚本文件并获取版本信息，在/pmon/common/main.c文件的相关函数中打印信息
